$(function() {
	
	//Date range picker
	$('#reservation').daterangepicker();
});