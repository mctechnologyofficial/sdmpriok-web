<div class="main-footer text-center">
    <div class="container">
        <div class="row row-sm">
            <div class="col-md-12">
                <span>©Copyright 2022 <a href="javascript:void(0)">Indonesia Power</a>. Designed by <a href="javascript:void(0)">MC TECHNOLOGY</a> All rights reserved.</span>
            </div>
        </div>
    </div>
</div>
