@extends('layouts.master')
@section('title', 'Home')

@section('content')
    <div class="row">
        <div class="col-lg-12">
            <div class="card custom-card">
                <div class="card-body">
                    {{--  --}}
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js')

@endsection
