@extends('layouts.master')
@section('title', 'Coaching Mentoring')

@section('content')
    <div class="row row-sm">
        <div class="col-lg-12">
            <div class="card custom-card">
                <div class="card-body text-center">
                    <h4 class="font-weight-bold">Fawwaz Hudzalfah Saputra</h4>
                    <h5>Senior Operator Control Room</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="row row-sm">
        <div class="col-lg-6">
            <div class="card custom-card">
                <div class="card-body">
                    {{--  --}}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card custom-card">
                <div class="card-body">
                    {{--  --}}
                </div>
            </div>
        </div>
    </div>
@endsection